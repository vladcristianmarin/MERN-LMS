const group = {
	code: '1087',
	school: 'ASE Bucuresti',
	yearOfStudy: '3',
	students: [],
};

export default group;
